Theme Name: RightNow
URI: http://www.renklibeyaz.com 

Description: Full Background Wordpress Theme 
Theme
Author: RenkliBeyaz - Salih �zoval�
Author URI: http://www.renklibeyaz.com

Version: 1.1.0

License: RenkliBeyaz - Salih �zoval�
License URI: http://www.renklibeyaz.com/terms-and-conditions/

Tags: Dark, Light